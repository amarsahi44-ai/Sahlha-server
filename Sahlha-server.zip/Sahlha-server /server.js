const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

const db = new sqlite3.Database('./db.sqlite');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    whatsapp TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER,
    fullname TEXT,
    phone TEXT,
    address TEXT,
    delivery TEXT,
    status TEXT
  )`);
});

app.post('/login', (req,res)=>{
  const {username,password} = req.body;
  db.get(
    "SELECT * FROM users WHERE username=? AND password=?",
    [username,password],
    (err,row)=>{
      if(row) res.json({success:true,user:row});
      else res.json({success:false});
    }
  );
});

app.post('/order',(req,res)=>{
  const {userId,fullname,phone,address,delivery} = req.body;
  const status = (phone.length===10 && address.length>5) ? "موثوق" : "مشكوك";
  db.run(
    "INSERT INTO orders VALUES (NULL,?,?,?,?,?,?)",
    [userId,fullname,phone,address,delivery,status],
    ()=>res.json({success:true,status})
  );
});

app.get('/orders/:id',(req,res)=>{
  db.all(
    "SELECT * FROM orders WHERE userId=?",
    [req.params.id],
    (err,rows)=>res.json(rows)
  );
});

app.listen(PORT,()=>console.log("Server running"));
