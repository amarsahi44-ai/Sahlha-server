let user=null;
function login(){
 fetch('/login',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({
    username:document.getElementById('user').value,
    password:document.getElementById('pass').value
  })
 }).then(r=>r.json()).then(d=>{
  if(d.success){
   user=d.user;
   login.style.display='none';
   dash.style.display='block';
   load();
  }
 });
}
function send(){
 fetch('/order',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({
    userId:user.id,
    fullname:fullname.value,
    phone:phone.value,
    address:address.value,
    delivery:delivery.value
  })
 }).then(()=>load());
}
function load(){
 fetch('/orders/'+user.id).then(r=>r.json()).then(data=>{
  orders.innerHTML='';
  data.forEach(o=>{
   orders.innerHTML+=`
   <tr>
    <td>${o.fullname}</td>
    <td>${o.status}</td>
    <td><a target="_blank"
     href="https://wa.me/${user.whatsapp}?text=سلام ${o.fullname}">
     واتساب</a></td>
   </tr>`;
  });
 });
}
